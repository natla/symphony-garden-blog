// set current  year in the footer:
var date = document.querySelector('.date');
var currentYear = new Date().getFullYear();
date.innerText = currentYear;